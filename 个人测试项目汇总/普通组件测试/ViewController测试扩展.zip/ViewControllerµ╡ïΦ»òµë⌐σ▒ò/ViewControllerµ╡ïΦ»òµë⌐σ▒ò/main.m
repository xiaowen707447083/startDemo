//
//  main.m
//  ViewController测试扩展
//
//  Created by xiaowen.chen on 16/6/8.
//  Copyright © 2016年 xw.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
