//
//  UIViewController+Base.h
//  ViewController测试扩展
//
//  Created by xiaowen.chen on 16/6/8.
//  Copyright © 2016年 xw.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Base)

@end
