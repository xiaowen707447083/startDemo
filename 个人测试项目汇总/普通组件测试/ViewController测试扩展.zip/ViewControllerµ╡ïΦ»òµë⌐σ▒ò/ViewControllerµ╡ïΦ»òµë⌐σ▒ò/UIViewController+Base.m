//
//  UIViewController+Base.m
//  ViewController测试扩展
//
//  Created by xiaowen.chen on 16/6/8.
//  Copyright © 2016年 xw.com. All rights reserved.
//

#import "UIViewController+Base.h"

@implementation UIViewController (Base)

//获取类名

@end
