//
//  AppDelegate+Base.h
//  ViewController测试扩展
//
//  Created by xiaowen.chen on 16/6/8.
//  Copyright © 2016年 xw.com. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Base)

@property(nonatomic,assign)Boolean isFrontPush;

@end
